
        $(document).ready(function(){
            $('#mainmenu .menu li').hover(
                function() {
                    $(this).find('ul:first').show();
                    $(this).find('a:first').addClass("hover");
                },
                function() {
                    $(this).find('ul:first').hide();
                    $(this).find('a:first').removeClass("hover");
                }
            );
			
			
			

			
		
	
    

  
        });
		
		
		
		